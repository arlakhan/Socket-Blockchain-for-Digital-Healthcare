
import java.io.*;
import java.net.Socket;
import java.util.List;

public class BlockchainClient {
    private static final String HOST = "localhost";
    private static final int PORT = 12345;

    public static void main(String[] args) {
        try (Socket socket = new Socket(HOST, PORT);
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream());
             ObjectInputStream in = new ObjectInputStream(socket.getInputStream())) {

            // Example of adding a new block
            out.writeObject("addBlock");
            out.writeObject("Patient A data...");

            String response = (String) in.readObject();
            System.out.println(response);

            // Example of getting the blockchain
            out.writeObject("getBlockchain");
            @SuppressWarnings("unchecked")
			List<Block> blockchain = (List<Block>) in.readObject();
            for (Block block : blockchain) {
                System.out.println("Block: " + block.hash + ", Previous: " + block.previousHash + ", Data: " + block);
            }
        } catch (IOException | ClassNotFoundException e) {
            //e.printStackTrace();
        }
    }
}
