
import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;

public class BlockchainServer {
    private static final int PORT = 12345;

    public static void main(String[] args) {
        Blockchain.addBlock(new Block("Genesis Block", "0"));
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            System.out.println("Server is listening on port " + PORT);
            while (true) {
                Socket socket = serverSocket.accept();
                new ClientHandler(socket).start();
            }
        } catch (IOException e) {
            //e.printStackTrace();
        }
    }
}

class ClientHandler extends Thread {
    private Socket socket;

    public ClientHandler(Socket socket) {
        this.socket = socket;
    }

    @Override
    public void run() {
        try (ObjectInputStream in = new ObjectInputStream(socket.getInputStream());
             ObjectOutputStream out = new ObjectOutputStream(socket.getOutputStream())) {

            String action = (String) in.readObject();
            switch (action) {
                case "addBlock":
                    String data = (String) in.readObject();
                    Block newBlock = new Block(data, Blockchain.blockchain.get(Blockchain.blockchain.size() - 1).hash);
                    Blockchain.addBlock(newBlock);
                    out.writeObject("Block added: " + newBlock.hash);
                    break;
                case "getBlockchain":
                    out.writeObject(Blockchain.blockchain);
                    break;
                default:
                    out.writeObject("Invalid action");
                    break;
            }
        } catch (IOException | ClassNotFoundException e) {
           // e.printStackTrace();
        }
    }
}
